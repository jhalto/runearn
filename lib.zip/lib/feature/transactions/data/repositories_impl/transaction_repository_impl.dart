import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:runearn/feature/transactions/data/datasources/local/transaction_db.dart';
import 'package:runearn/feature/transactions/data/datasources/remote/transaction_remote_datasource.dart';
import 'package:runearn/feature/transactions/data/models/transaction_model.dart';
import 'package:runearn/feature/transactions/domain/entities/transaction.dart';
import 'package:runearn/feature/transactions/domain/repositories/transaction_repository.dart';

class TransactionRepositoryImpl implements TransactionRepository {
  final TransactionRemoteDataSource remoteDataSource;

  TransactionRepositoryImpl({
    TransactionRemoteDataSource? remoteDataSource,
  }) : remoteDataSource = remoteDataSource ?? TransactionRemoteDataSource();

  Future<bool> get _hasInternet async {
    final result = await Connectivity().checkConnectivity();

    return !result.contains(ConnectivityResult.none);
  }

  @override
  Future<List<Transaction>> getTransactions() async {
    final hasInternet = await _hasInternet;

    if (hasInternet) {
      try {
        await syncPendingTransactions();

        final remoteData = await remoteDataSource.fetchTransactions();

        for (final item in remoteData) {
          await TransactionDB.upsertFromRemote(item);
        }
      } catch (e) {
        // If Firebase fails, app still shows local data.
      }
    }

    final data = await TransactionDB.getTransactions();

    return data.map((e) {
      return TransactionModel.fromMap(e).toEntity();
    }).toList();
  }

  @override
  Future<void> addTransaction(Transaction transaction) async {
    final model = TransactionModel.fromEntity(transaction);

    final data = {
      ...model.toMap(),
      'isSynced': 0,
      'updatedAt': DateTime.now().toIso8601String(),
      'deletedAt': null,
    };

    // 1. Save locally first
    await TransactionDB.insertTransaction(data);

    // 2. Try Firebase upload
    if (await _hasInternet) {
      try {
        await remoteDataSource.uploadTransaction(data);
        await TransactionDB.markAsSynced(data['id']);
      } catch (e) {
        // Keep as unsynced
      }
    }
  }

  @override
  Future<void> updateTransaction(Transaction transaction) async {
    final model = TransactionModel.fromEntity(transaction);

    final data = {
      ...model.toMap(),
      'isSynced': 0,
      'updatedAt': DateTime.now().toIso8601String(),
    };

    // 1. Update local first
    await TransactionDB.updateTransaction(data);

    // 2. Try Firebase update
    if (await _hasInternet) {
      try {
        await remoteDataSource.uploadTransaction(data);
        await TransactionDB.markAsSynced(data['id']);
      } catch (e) {
        // Keep as unsynced
      }
    }
  }

  @override
  Future<void> deleteTransaction(String id) async {
    // 1. Soft delete locally
    await TransactionDB.deleteTransaction(id);

    // 2. Try Firebase delete
    if (await _hasInternet) {
      try {
        await remoteDataSource.uploadTransaction({
          'id': id,
          'deletedAt': DateTime.now().toIso8601String(),
          'updatedAt': DateTime.now().toIso8601String(),
        });

        await TransactionDB.markAsSynced(id);
      } catch (e) {
        // Keep as unsynced
      }
    }
  }

  Future<void> syncPendingTransactions() async {
    if (!await _hasInternet) return;

    final unsyncedItems = await TransactionDB.getUnsyncedTransactions();

    for (final item in unsyncedItems) {
      try {
        await remoteDataSource.uploadTransaction(item);
        await TransactionDB.markAsSynced(item['id']);
      } catch (e) {
        // Continue next item
      }
    }
  }
}