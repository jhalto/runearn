import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:runearn/feature/auth/domain/repositories/auth_repository.dart';

import 'auth_event.dart';
import 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository authRepository;

  AuthBloc({required this.authRepository}) : super(AuthInitial()) {
    on<LoginWithEmailPasswordEvent>(_loginWithEmailPassword);
    on<LoginWithGoogleEvent>(_loginWithGoogle);
    on<LoginAsGuestEvent>(_loginAsGuest);
    on<LogoutEvent>(_logout);
    on<CheckAuthStatusEvent>(_checkAuthStatus);
  }

  Future<void> _loginWithEmailPassword(
    LoginWithEmailPasswordEvent event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());

    try {
      final userCredential = await authRepository.loginWithEmailPassword(
        event.credential,
      );

      final user = userCredential.user;

      if (user == null) {
        emit(AuthFailure(message: 'Login failed. User not found.'));
        return;
      }

      emit(AuthAuthenticated(user: user));
    } on FirebaseAuthException catch (e) {
      emit(AuthFailure(message: e.message ?? 'Login failed'));
    } catch (e) {
      emit(AuthFailure(message: e.toString()));
    }
  }

  Future<void> _loginWithGoogle(
    LoginWithGoogleEvent event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());

    try {
      final userCredential = await authRepository.loginWithGoogle();

      final user = userCredential.user;

      if (user == null) {
        emit(AuthFailure(message: 'Google login failed. User not found.'));
        return;
      }

      emit(AuthAuthenticated(user: user));
    } on FirebaseAuthException catch (e) {
    
      emit(AuthFailure(message: e.message ?? 'Google login failed'));
    } catch (e) {
      emit(AuthFailure(message: 'Google login failed. Please try again.'));
    }
  }

  Future<void> _loginAsGuest(
    LoginAsGuestEvent event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());

    try {
      final userCredential = await authRepository.loginAsGuest();

      final user = userCredential.user;

      if (user == null) {
        emit(AuthFailure(message: 'Guest login failed. User not found.'));
        return;
      }

      emit(AuthAuthenticated(user: user));
    } on FirebaseAuthException catch (e) {
      emit(AuthFailure(message: e.message ?? 'Guest login failed'));
    } catch (e) {
      emit(AuthFailure(message: e.toString()));
    }
  }

  Future<void> _logout(LogoutEvent event, Emitter<AuthState> emit) async {
    emit(AuthLoading());

    try {
      await authRepository.logout();

      emit(AuthUnauthenticated());
    } catch (e) {
      print(e);
      emit(AuthFailure(message: e.toString()));
    }
  }

  Future<void> _checkAuthStatus(
    CheckAuthStatusEvent event,
    Emitter<AuthState> emit,
  ) async {
    final user = authRepository.getCurrentUser();

    if (user == null) {
      emit(AuthUnauthenticated());
    } else {
      emit(AuthAuthenticated(user: user));
    }
  }
}
