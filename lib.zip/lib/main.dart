import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:runearn/config/route/app_routes.dart';
import 'package:runearn/config/route/route_names.dart';
import 'package:runearn/core/di/injection_container.dart';
import 'package:runearn/config/theme/app_theme.dart';
import 'package:runearn/config/theme/theme_cubit.dart';
import 'package:runearn/feature/auth/presentation/bloc/auth_bloc.dart';
import 'package:runearn/feature/transactions/data/datasources/local/transaction_db.dart';
import 'package:runearn/firebase_options.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await dotenv.load(fileName: ".env.dev");
  // 🔥 REQUIRED FOR WINDOWS / LINUX / MAC
  if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  }

  await TransactionDB.init();
  await dependencyInjection();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  String getInitialRoute() {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      return Routes.login;
    }
    return Routes.home;
  }

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<ThemeCubit>(create: (_) => sl<ThemeCubit>()),
        BlocProvider<AuthBloc>(create: (_) => sl<AuthBloc>()),
      ],
      child: BlocBuilder<ThemeCubit, ThemeState>(
        builder: (context, state) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            title: "RunEarn",
            theme: AppTheme.light,
            darkTheme: AppTheme.dark,

            themeMode: state.isDark ? ThemeMode.dark : ThemeMode.light,
            initialRoute: getInitialRoute(),
            onGenerateRoute: AppRoutes.onGenerateRoute,
          );
        },
      ),
    );
  }
}
