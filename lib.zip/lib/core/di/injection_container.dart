import 'package:get_it/get_it.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:runearn/config/theme/theme_cubit.dart';

// Auth
import 'package:runearn/feature/auth/data/data_sources/remote/auth_remote_datasource.dart';
import 'package:runearn/feature/auth/data/repository_impl/auth_remote_datasource_impl.dart';
import 'package:runearn/feature/auth/data/repository_impl/auth_repository_impl.dart';
import 'package:runearn/feature/auth/domain/repositories/auth_repository.dart';
import 'package:runearn/feature/auth/domain/usecases/google_login_use_case.dart';
import 'package:runearn/feature/auth/domain/usecases/guest_login_use_case.dart';
import 'package:runearn/feature/auth/domain/usecases/login_use_case.dart';
import 'package:runearn/feature/auth/domain/usecases/logout_use_case.dart';
import 'package:runearn/feature/auth/presentation/bloc/auth_bloc.dart';

// Transactions
import 'package:runearn/feature/transactions/data/datasources/remote/transaction_remote_datasource.dart';
import 'package:runearn/feature/transactions/data/repositories_impl/transaction_repository_impl.dart';
import 'package:runearn/feature/transactions/domain/repositories/transaction_repository.dart';
import 'package:runearn/feature/transactions/presentation/bloc/transaction_bloc.dart';

final sl = GetIt.instance;

Future<void> dependencyInjection() async {
  // External
  sl.registerLazySingleton<FirebaseAuth>(() => FirebaseAuth.instance);
  sl.registerLazySingleton<FirebaseFirestore>(() => FirebaseFirestore.instance);

  // Theme
  sl.registerFactory<ThemeCubit>(() => ThemeCubit());

  // Auth Data Source
  sl.registerLazySingleton<AuthRemoteDataSource>(
    () => AuthRemoteDataSourceImpl(firebaseAuth: sl<FirebaseAuth>()),
  );

  // Auth Repository
  sl.registerLazySingleton<AuthRepository>(
    () => AuthRepositoryImpl(remoteDataSource: sl<AuthRemoteDataSource>()),
  );

  // Auth Use Cases
  sl.registerLazySingleton<LoginUseCase>(
    () => LoginUseCase(sl<AuthRepository>()),
  );

  sl.registerLazySingleton<GoogleLoginUseCase>(
    () => GoogleLoginUseCase(sl<AuthRepository>()),
  );

  sl.registerLazySingleton<GuestLoginUseCase>(
    () => GuestLoginUseCase(sl<AuthRepository>()),
  );

  sl.registerLazySingleton<LogoutUseCase>(
    () => LogoutUseCase(sl<AuthRepository>()),
  );
  // Auth Bloc

  sl.registerFactory<AuthBloc>(
    () => AuthBloc(authRepository: sl<AuthRepository>()),
  );

  // Transaction Remote Data Source
  sl.registerLazySingleton<TransactionRemoteDataSource>(
    () => TransactionRemoteDataSource(
      firestore: sl<FirebaseFirestore>(),
      auth: sl<FirebaseAuth>(),
    ),
  );

  // Transaction Repository
  sl.registerLazySingleton<TransactionRepository>(
    () => TransactionRepositoryImpl(
      remoteDataSource: sl<TransactionRemoteDataSource>(),
    ),
  );

  // Transaction Bloc
  sl.registerFactory<TransactionBloc>(
    () => TransactionBloc(sl<TransactionRepository>()),
  );
}
